#!/bin/bash

# AWS Lambda Deployment Script for Bedrock Image Generation
# This script deploys the Lambda function to handle Nova Canvas and Titan Image Generation

echo "🚀 Deploying Bedrock Image Generation Lambda Function..."

# Set variables
FUNCTION_NAME="BedrockImageGeneration"
LAMBDA_ROLE_NAME="BedrockImageGenerationRole"
API_GATEWAY_NAME="formula-platform-api"
S3_BUCKET="formula-platform-images"
REGION="us-east-1"

# Check if AWS CLI is configured
if ! aws sts get-caller-identity > /dev/null 2>&1; then
    echo "❌ AWS CLI not configured. Please run 'aws configure' first."
    exit 1
fi

echo "✅ AWS CLI configured"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Create S3 bucket for images if it doesn't exist
echo "🪣 Creating S3 bucket for generated images..."
aws s3 mb s3://$S3_BUCKET --region $REGION 2>/dev/null || echo "Bucket may already exist"

# Set bucket policy for public read access
echo "🔒 Setting S3 bucket policy..."
cat > bucket-policy.json << EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "PublicReadGetObject",
            "Effect": "Allow",
            "Principal": "*",
            "Action": "s3:GetObject",
            "Resource": "arn:aws:s3:::$S3_BUCKET/*"
        }
    ]
}
EOF

aws s3api put-bucket-policy --bucket $S3_BUCKET --policy file://bucket-policy.json

# Create IAM role for Lambda if it doesn't exist
echo "👤 Creating IAM role for Lambda..."
cat > trust-policy.json << EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "Service": "lambda.amazonaws.com"
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
EOF

# Create the role
aws iam create-role --role-name $LAMBDA_ROLE_NAME --assume-role-policy-document file://trust-policy.json 2>/dev/null || echo "Role may already exist"

# Create and attach policy for Bedrock and S3 access
cat > lambda-policy.json << EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "logs:CreateLogGroup",
                "logs:CreateLogStream",
                "logs:PutLogEvents"
            ],
            "Resource": "arn:aws:logs:*:*:*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:InvokeModelWithResponseStream"
            ],
            "Resource": [
                "arn:aws:bedrock:*::foundation-model/amazon.nova-canvas-v1:0",
                "arn:aws:bedrock:*::foundation-model/amazon.titan-image-generator-v1"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:PutObject",
                "s3:PutObjectAcl",
                "s3:GetObject"
            ],
            "Resource": "arn:aws:s3:::$S3_BUCKET/*"
        }
    ]
}
EOF

aws iam put-role-policy --role-name $LAMBDA_ROLE_NAME --policy-name BedrockImageGenerationPolicy --policy-document file://lambda-policy.json

# Get role ARN
ROLE_ARN=$(aws iam get-role --role-name $LAMBDA_ROLE_NAME --query 'Role.Arn' --output text)
echo "📋 Using IAM Role: $ROLE_ARN"

# Wait a bit for IAM role to propagate
echo "⏳ Waiting for IAM role to propagate..."
sleep 10

# Create deployment package
echo "📦 Creating deployment package..."
zip -r deployment.zip index.js package.json node_modules/

# Create or update Lambda function
echo "🔧 Deploying Lambda function..."
aws lambda get-function --function-name $FUNCTION_NAME > /dev/null 2>&1

if [ $? -eq 0 ]; then
    echo "📝 Updating existing Lambda function..."
    aws lambda update-function-code \
        --function-name $FUNCTION_NAME \
        --zip-file fileb://deployment.zip

    aws lambda update-function-configuration \
        --function-name $FUNCTION_NAME \
        --timeout 60 \
        --memory-size 1024 \
        --environment Variables="{AWS_REGION=$REGION,S3_BUCKET=$S3_BUCKET}"
else
    echo "🆕 Creating new Lambda function..."
    aws lambda create-function \
        --function-name $FUNCTION_NAME \
        --runtime nodejs18.x \
        --role $ROLE_ARN \
        --handler index.handler \
        --zip-file fileb://deployment.zip \
        --timeout 60 \
        --memory-size 1024 \
        --environment Variables="{AWS_REGION=$REGION,S3_BUCKET=$S3_BUCKET}" \
        --description "Generate cosmetic product packaging images using AWS Bedrock Nova Canvas and Titan"
fi

# Add API Gateway permission to Lambda
echo "🌐 Setting up API Gateway permissions..."
aws lambda add-permission \
    --function-name $FUNCTION_NAME \
    --statement-id api-gateway-invoke \
    --action lambda:InvokeFunction \
    --principal apigateway.amazonaws.com \
    --source-arn "arn:aws:execute-api:$REGION:*:*" 2>/dev/null || echo "Permission may already exist"

# Clean up temporary files
rm -f deployment.zip trust-policy.json lambda-policy.json bucket-policy.json

echo "✅ Lambda function deployed successfully!"
echo "🔗 Function ARN: $(aws lambda get-function --function-name $FUNCTION_NAME --query 'Configuration.FunctionArn' --output text)"
echo "🪣 S3 Bucket: s3://$S3_BUCKET"
echo ""
echo "Next steps:"
echo "1. Update your API Gateway to route /prod/generate-image to this Lambda function"
echo "2. Test the function with your Next.js application"
echo "3. Monitor CloudWatch logs for any issues"