# AWS Bedrock Image Generation Lambda

This Lambda function generates premium cosmetic product packaging images using AWS Bedrock's Nova Canvas and Titan Image Generator models.

## Features

- **Dual Model Support**: Nova Canvas (primary) and Titan Image Generator (fallback)
- **Professional Packaging**: Generates studio-quality product mockups
- **S3 Integration**: Automatically uploads images to S3 with public access
- **Error Handling**: Comprehensive error handling and logging
- **CORS Support**: Ready for web application integration

## Architecture

```
Next.js App → API Gateway → Lambda → AWS Bedrock → S3 Storage
                                      ↓
                                 Nova Canvas / Titan
```

## Deployment

### Prerequisites

1. AWS CLI configured with appropriate credentials
2. IAM permissions for:
   - Lambda function creation/update
   - Bedrock model access (Nova Canvas, Titan)
   - S3 bucket operations
   - IAM role management

### Quick Deploy

```bash
cd lambda/image-generation
chmod +x deploy.sh
./deploy.sh
```

### Manual Deployment

1. Install dependencies:
   ```bash
   npm install
   ```

2. Create deployment package:
   ```bash
   zip -r deployment.zip index.js package.json node_modules/
   ```

3. Create Lambda function:
   ```bash
   aws lambda create-function \
     --function-name BedrockImageGeneration \
     --runtime nodejs18.x \
     --role arn:aws:iam::YOUR-ACCOUNT:role/BedrockImageGenerationRole \
     --handler index.handler \
     --zip-file fileb://deployment.zip \
     --timeout 60 \
     --memory-size 1024
   ```

## API Usage

### Request Format

```json
POST /prod/generate-image
{
  "prompt": "Generate a premium cosmetic product packaging mockup...",
  "model": "amazon.nova-canvas-v1:0",
  "width": 1024,
  "height": 1024,
  "quality": "premium",
  "cfg_scale": 8.0,
  "seed": 123456
}
```

### Response Format

```json
{
  "success": true,
  "imageUrl": "https://formula-platform-images.s3.amazonaws.com/generated-images/1234567890-packaging-mockup.png",
  "s3_url": "https://formula-platform-images.s3.amazonaws.com/generated-images/1234567890-packaging-mockup.png",
  "presigned_url": "https://formula-platform-images.s3.amazonaws.com/...",
  "metadata": {
    "model": "amazon.nova-canvas-v1:0",
    "dimensions": "1024x1024",
    "generated_at": "2024-01-01T12:00:00.000Z",
    "s3_key": "generated-images/1234567890-packaging-mockup.png"
  }
}
```

## Environment Variables

- `AWS_REGION`: AWS region (default: us-east-1)
- `S3_BUCKET`: S3 bucket for image storage (default: formula-platform-images)
- `AWS_ACCESS_KEY_ID`: AWS access key (set by Lambda environment)
- `AWS_SECRET_ACCESS_KEY`: AWS secret key (set by Lambda environment)

## Models Supported

### Amazon Nova Canvas (`amazon.nova-canvas-v1:0`)
- Primary model for high-quality image generation
- Best for detailed product photography
- Supports up to 1024x1024 resolution

### Amazon Titan Image Generator (`amazon.titan-image-generator-v1`)
- Fallback model for reliability
- Good for general product images
- Fast generation times

## Monitoring

### CloudWatch Logs
- Function logs: `/aws/lambda/BedrockImageGeneration`
- Monitor for generation errors and performance

### CloudWatch Metrics
- Duration: Track image generation time
- Errors: Monitor failed generations
- Invocations: Track usage patterns

## Cost Optimization

- **Memory**: 1024MB (optimal for image processing)
- **Timeout**: 60 seconds (allows for model processing)
- **S3 Lifecycle**: Consider adding lifecycle rules for old images
- **Bedrock**: Nova Canvas ~$0.04 per image, Titan ~$0.008 per image

## Security

- IAM role with minimal required permissions
- S3 bucket with public read access for generated images
- No sensitive data logged in CloudWatch

## Troubleshooting

### Common Issues

1. **403 Forbidden**: Check IAM permissions for Bedrock access
2. **Timeout**: Increase Lambda timeout or optimize prompt
3. **S3 Upload Failed**: Verify S3 bucket permissions
4. **Model Not Found**: Ensure Bedrock models are available in region

### Debug Mode

Enable detailed logging by setting environment variable:
```bash
DEBUG=true
```

## Integration with Formula Platform

This Lambda function is integrated with the Formula Platform Next.js application:

- **Endpoint**: `https://gcle21npca.execute-api.ap-southeast-1.amazonaws.com/prod/generate-image`
- **Usage**: Called from `/src/app/api/generate-image/route.ts`
- **Fallback**: SVG demo images when Lambda is unavailable

## Support

For issues or questions, check:
1. CloudWatch logs for detailed error messages
2. AWS Bedrock service status
3. S3 bucket permissions and quotas